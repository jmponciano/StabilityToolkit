# Installing and using the package.  
# The following three lines only need to be ran only once!
install.packages("devtools")
library("devtools")
install("StabilityToolkit")


# Now Uploading the library
library("StabilityToolkit")
help(package="StabilityToolkit")
print(data.compet)
print(data.stabexp)
print(data.compet2)
print(data.stabexp2)

# Just for fun: note how the log-likelihood forcing the model to have a negative cost is higher in this case...
jointflexssMLEs(data.compet=data.compet, data.stabexp=data.stabexp, nrc=3, nrepexp=3,gen=10, B=1000, neg.cost=FALSE)

jointflexssMLEs(data.compet=data.compet, data.stabexp=data.stabexp, nrc=3, nrepexp=3,gen=10, B=1000, neg.cost=TRUE)


# Just for fun: note how the log-likelihood forcing the model to have a negative cost is higher in this case...
jointflexssMLEs(data.compet=data.compet2, data.stabexp=data.stabexp2, nrc=3, nrepexp=3,gen=10, B=100, neg.cost=FALSE)

jointflexssMLEs(data.compet=data.compet2, data.stabexp=data.stabexp2, nrc=3, nrepexp=3,gen=10, B=100, neg.cost=TRUE)

HT.bootstrappedMLEs(problem.counts=data.stabexp2[,1:4], nrepsi=3, Dmat=data.stabexp2[,5:7], gens=10, B=100)

flexss.bootstrappedMLEs(problem.counts=trial.data[,1:7], nrepsi=6,Dmat=trial.data[,8:13], gens=10,B=1,neg.cost=FALSE)

trial <- dynamic.fit(data1=data.stabexp,model="SS",gen=10,true.cost=FALSE, add.compet.data=FALSE, comb=FALSE, data2=NULL, B=1000)

