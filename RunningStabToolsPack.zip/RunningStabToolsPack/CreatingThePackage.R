# Creating the stability toolkit package
# From hilary Parker's blog: 
# https://hilaryparker.com/2014/04/29/writing-an-r-package-from-scratch/
# If you're just making Changes, go to line 41

install.packages("devtools")
devtools::install_github("klutometis/roxygen")

library("devtools")
library(roxygen2)

setwd("~/Documents/UFL/RESEARCH/EvaTop/RunningStabToolsPack")
create("StabilityToolkit")

setwd("./StabilityToolkit")
document()

setwd("..")
install("StabilityToolkit")

# Adding data that comes with the package
# First in the the toolkit folder, create a ne folder called inst, 
# with a subfolder called extdata
# Now upload two sample data sets: I uploaded AncA.txt and AncA.HancPanc.txt
# These correspond to one competition data set for the ancestor, clones A and
# one stability experiment with the ancestor and ancestral plasmid, clone A

# I ran the data reading lines from te JointEstimation1.0.R file and then did:
write.matrix(x=data.compet, file="inst/extdata/datacompet.txt")
write.matrix(x=data.stabexp, file="inst/extdata/datastabexp.txt")

# But the data.compet and data.stabexp objects can be made available to users 
# after installing the package by typing:
devtools::use_data(data.compet)
devtools::use_data(data.stabexp)

# Do the same with the A1 clones (the above are the ancestors)
devtools::use_data(data.compet2)
devtools::use_data(data.stabexp2)

library(MASS)
write.matrix(x=data.compet2, file="inst/extdata/datacompet2.txt")
write.matrix(x=data.stabexp2, file="inst/extdata/datastabexp2.txt")


# The write.matrix lines above make the raw data readable by typing:
# system.file("extdata", "datacompet", package="StabilityToolkit")

######  If you want to introduce changes to the package functions, before modifying them open R
######  and move inside the package directory
setwd("~/Documents/UFL/RESEARCH/EvaTop/StabilityTools-Package/StabilityToolkit")
library("devtools")
library(roxygen2)

######  Then proceed to make the changes to the R functions and when done, type:
document() # This updates the changes in the functions and in the documentations

######  Next, to re-install the package, move up to the parent directory and use the
######  install function from devtools

setwd("..")
install("StabilityToolkit")



