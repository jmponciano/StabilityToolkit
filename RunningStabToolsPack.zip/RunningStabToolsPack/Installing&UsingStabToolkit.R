# Installing and using the package.  
# The following three lines only need to be ran only once!
install.packages("devtools")
library("devtools")
install("StabilityToolkit")


# Now Uploading the library
library("StabilityToolkit")
help(package="StabilityToolkit")

#Uploading a txt data set
trial.data <- as.matrix(read.table(file="G1000.txt", header=TRUE))
print(trial.data)

# Now fitting the segregation-selection (SS) model to this trial data set
simpleSSfit <- dynamic.fit(data1=trial.data,model="SS")

# Try fitting the HT model
simpleHTfit <- dynamic.fit(data1=trial.data,model="HT")

#Adding complexity: 
# 1. Assume the cost parameter is negative: i.e., bacteria with plasmid grows faster.  Just add
simpleSSfit <- dynamic.fit(data1=trial.data,model="SS", true.cost=FALSE)

# 2. Assume you have two stability assay data sets and want to test if they are driven by the same
#    biological parameters.  We can do that for the SS and for the HT models

trial.data2 <- trial.data # just use the same data as your second data set, for the sake of this ex.

comb.SSfit <- dynamic.fit(data1=trial.data,model="SS", comb=TRUE,data2=trial.data2)

comb.HTfit <- dynamic.fit(data1=trial.data,model="HT", comb=TRUE,data2=trial.data2)


### 
trial.data <- as.matrix(read.table(file="L1I1.HancPanc.txt", header=TRUE))
print(trial.data)

trial.data2 <- as.matrix(read.table(file="L1I1.HancPev.txt", header=TRUE))
print(trial.data2)

comb.SSfit <- dynamic.fit(data1=trial.data,model="SS", comb=TRUE,data2=trial.data2)

comb.HTfit <- dynamic.fit(data1=trial.data,model="HT", comb=TRUE,data2=trial.data2)


# 3. Assume you have data from a competition assay and from a stability assay and
#    you want to leverage the information in the competition assay to better estimate
#    the cost.  This package comes with two sample data sets to that effect, one 
#    is a stability assay, called data.compet and another called data.stabexp
#    These two data sets come from an Ancestral line, so cost is expected to be true cost
# 	 Check them out by typing
print(data.compet)
print(data.stabexp) 
add.compet.fit <- dynamic.fit(data1=data.stabexp,model="SS",add.compet.data=TRUE, data2=data.compet)


